Lifeline Service Developed using Mule Studio
